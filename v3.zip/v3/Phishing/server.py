import http.server
import socketserver
import logging
from logging.handlers import RotatingFileHandler
from datetime import datetime

PORT = 8040


class LoggingHandler(http.server.SimpleHTTPRequestHandler):
    def log_message(self, format, *args):
        message = f"{self.log_date_time_string()} - {format % args}\n"
        with open("server_log.txt", "a") as log_file:
            log_file.write(message)

Handler = LoggingHandler
with socketserver.TCPServer(("", PORT), LoggingHandler) as httpd:
    print(f"Serving at port {PORT}")
    httpd.serve_forever()
