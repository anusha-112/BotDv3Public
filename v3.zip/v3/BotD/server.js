import express from 'express';
import { promises as fs } from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import cors from 'cors';
import { Parser } from 'json2csv';
import serverless from 'serverless-http';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const app = express();
const port = 3000;

// Enable CORS for all routes
app.use(cors());

// Parse JSON bodies for all routes
app.use(express.json());

// Serve static files from the current directory
app.use(express.static('.'));

// Helper function to flatten and normalize the rules structure
function normalizeRules(rules) {
  const normalized = [];
  
  Object.entries(rules).forEach(([detectorName, detectorRules]) => {
    if (Array.isArray(detectorRules)) {
      detectorRules.forEach(rule => {
        normalized.push({
          detector: detectorName,
          ...rule
        });
      });
    } else if (typeof detectorRules === 'object') {
      if (detectorRules.parameters || detectorRules.conditions) {
        normalized.push({
          detector: detectorName,
          ...detectorRules
        });
      } else {
        Object.entries(detectorRules).forEach(([key, value]) => {
          normalized.push({
            detector: detectorName,
            name: key,
            ...value
          });
        });
      }
    }
  });
  
  return normalized;
}

// Endpoint to get all rules
app.get('/api/rules', async (req, res) => {
  try {
    const filePath = path.join(__dirname, 'json files', 'combined_rules.json');
    const content = await fs.readFile(filePath, 'utf8');
    const combinedRules = JSON.parse(content).botDetection;
   
    const normalizedRules = normalizeRules(combinedRules);

    res.json(normalizedRules);
  } catch (error) {
    console.error('Error reading rules:', error);
    res.status(500).json({ error: 'Failed to load rules' });
  }
});

function flattenObject(obj, parent, res = {}) {
  for (let key in obj) {
    let propName = parent ? parent + '.' + key : key;
    if (typeof obj[key] == 'object' && !Array.isArray(obj[key])) {
      flattenObject(obj[key], propName, res);
    } else {
      res[propName] = obj[key];
    }
  }
  return res;
}

app.post('/botdetected/json', async (req, res) => {
  try {
    const botInfo = req.body;
    console.log('Bot Detection Information:');
    console.log(JSON.stringify(botInfo, null, 2));

    const csvFilePath = path.join(__dirname, 'bot_detections.csv');

    const flattenedBotInfo = flattenObject(botInfo);

    // Define the fields to include
    const fieldsToInclude = [
      "isBot",
      "botKind",
      "detectedRules",
      "browserDetails.userAgent",
      "browserDetails.platform",
      "browserDetails.language",
      "browserDetails.cookiesEnabled",
      "browserDetails.doNotTrack",
      "browserDetails.screenResolution",
      "browserDetails.colorDepth",
      "browserDetails.plugins",
      "browserDetails.timezone",
      "browserDetails.webdriver",
      "browserDetails.languages",
      "browserDetails.productSub",
      "browserDetails.maxTouchPoints",
      "browserDetails.process",
      "browserDetails.android",
      "browserDetails.browserKind",
      "browserDetails.browserEngineKind",
      "browserDetails.mimeTypesConsistent",
      "browserDetails.evalLength",
      "browserDetails.webGL.vendor",
      "browserDetails.webGL.renderer",
      "browserDetails.windowExternal.present",
      "browserDetails.windowExternal.properties",
      "detectionTime",
      "detectorsResults.appVersion.bot",
      "detectorsResults.name.bot",
      "detectorsResults.rules.bot",
      "detectorsResults.distinctiveProperties.bot",
      "detectorsResults.documentElementKeys.bot",
      "detectorsResults.errorTrace.bot",
      "detectorsResults.evalLength.bot",
      "detectorsResults.functionBind.bot",
      "detectorsResults.languageInconsistency.bot",
      "detectorsResults.mimeTypesConsistence.bot",
      "detectorsResults.notificationPermission.bot",
      "detectorsResults.pluginsArray.bot",
      "detectorsResults.pluginsInconsistency.bot",
      "detectorsResults.process.bot",
      "detectorsResults.productSub.bot",
      "detectorsResults.rtt.bot",
      "detectorsResults.userAgent.bot",
      "detectorsResults.webDriver.bot",
      "detectorsResults.webGL.bot",
      "detectorsResults.windowExternal.bot",
      "detectorsResults.windowSize.bot",
      "appVersion.value",
      "appVersion.state",
      "userAgent.value",
      "userAgent.state",
      "webDriver.value",
      "webDriver.state",
      "languages.value",
      "languages.state",
      "productSub.value",
      "productSub.state",
      "pluginsArray.value",
      "pluginsArray.state",
      "pluginsLength.value",
      "pluginsLength.state",
      "windowSize.value.outerWidth",
      "windowSize.value.outerHeight",
      "windowSize.value.innerWidth",
      "windowSize.value.innerHeight",
      "windowSize.state",
      "documentFocus.value",
      "documentFocus.state",
      "rtt.value",
      "rtt.state",
      "errorTrace.value",
      "errorTrace.state",
      "documentElementKeys.value",
      "documentElementKeys.state",
      "functionBind.value",
      "functionBind.state",
      "distinctiveProps.value.awesomium",
      "distinctiveProps.value.cef",
      "distinctiveProps.value.phantom",
      "distinctiveProps.value.selenium",
      "distinctiveProps.value.webdriver",
      "distinctiveProps.value.domAutomation",
      "distinctiveProps.state",
      "notificationPermissions.value",
      "notificationPermissions.state"
    ];

    // Filter the flattenedBotInfo to include only the desired fields
    const filteredBotInfo = {};
    fieldsToInclude.forEach(field => {
      if (flattenedBotInfo.hasOwnProperty(field)) {
        filteredBotInfo[field] = flattenedBotInfo[field];
      }
    });

    // Create CSV data from filteredBotInfo
    let csvData = fieldsToInclude.map(field => {
      let value = filteredBotInfo[field];

      if (value === null || value === undefined) {
        return ''; // Leave empty for null or undefined values
      } else if (typeof value === 'object') {
        // Assuming stringifyNestedObject correctly handles object types
        let stringValue = stringifyNestedObject(value);
        // Escape double quotes and wrap the entire value in quotes
        return `"${stringValue.replace(/"/g, '""')}"`;
      } else if (typeof value === 'string') {
        // Replace newlines with space and wrap in quotes
        value = value.replace(/\n/g, ' ').replace(/"/g, '""');
        return `"${value}"`;
      } else {
        return value; // Return as-is for other types (number, boolean, etc.)
      }
    }).join(',');

    // Example of helper function stringifyNestedObject
    function stringifyNestedObject(obj) {
      // Implement logic to stringify nested object
      return JSON.stringify(obj);
    }

    const fields = Object.keys(filteredBotInfo);
    const parser = new Parser({ fields });

    // Check if the CSV file exists
    let fileExists;
    try {
      await fs.access(csvFilePath);
      fileExists = true;
    } catch {
      fileExists = false;
    }

    // Append data without headers if the file exists
    if (fileExists) {
      await fs.appendFile(csvFilePath, `\n${csvData}`, 'utf8');
    } else {
      // Write data with headers if the file does not exist
      const header = fieldsToInclude.join(',') + '\n';
      await fs.writeFile(csvFilePath, header + csvData, 'utf8');
    }

    res.sendStatus(200);
  } catch (error) {
    console.error('Error processing bot detection:', error);
    res.status(500).json({ error: 'Failed to process bot detection' });
  }
});

export const handler = serverless(app);

// Start the server if this script is run directly
if (require.main === module) {
  app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
  });
}
