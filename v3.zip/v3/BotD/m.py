from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException
import time
import webbrowser

# Update the driver_path with the correct path to the latest ChromeDriver
driver_path = "/home/kali/Downloads/chromedriver-linux64/chromedriver"

chrome_options = Options()
chrome_options.add_argument("--no-sandbox")
chrome_options.add_argument("--disable-dev-shm-usage")
chrome_options.add_argument("--headless")  # Headless mode
chrome_options.add_argument("--disable-blink-features=AutomationControlled")  # Disable blink features
chrome_options.add_experimental_option("excludeSwitches", ["enable-automation"])
chrome_options.add_experimental_option('useAutomationExtension', False)

service = Service(driver_path)

def open_website():
    driver = webdriver.Chrome(service=service, options=chrome_options)
    driver.maximize_window()
    driver.get("http://127.0.0.1:3000/")
    
    # Inject JavaScript to set bot detection properties
    driver.execute_script("""
        Object.defineProperty(navigator, 'webdriver', {get: () => true});
        Object.defineProperty(navigator, 'languages', {get: () => ['en-US', 'en']});
        Object.defineProperty(navigator, 'plugins', {get: () => [1, 2, 3]});
        Object.defineProperty(navigator, 'hardwareConcurrency', {get: () => 2});
    """)
    
    # Wait for potential redirects
    try:
        WebDriverWait(driver, 10).until(EC.url_changes("http://127.0.0.1:3000/"))
    except TimeoutException:
        print("No redirect occurred within 10 seconds")
    
    # Print the final URL
    print(f"Final URL: {driver.current_url}")
    webbrowser.open(driver.current_url)
    
    return driver

# Run the function
driver = open_website()

# Keep the browser open for 10 seconds before closing
time.sleep(10)
driver.quit()
